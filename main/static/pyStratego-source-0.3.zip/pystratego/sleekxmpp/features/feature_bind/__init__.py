"""
    SleekXMPP: The Sleek XMPP Library
    Copyright (C) 2011  Nathanael C. Fritz
    This file is part of SleekXMPP.

    See the file LICENSE for copying permission.
"""

from sleekxmpp.features.feature_bind.bind import feature_bind
from sleekxmpp.features.feature_bind.stanza import Bind
